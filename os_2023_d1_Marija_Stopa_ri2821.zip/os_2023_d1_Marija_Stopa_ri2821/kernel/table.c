#include "table.h"

#define NUM_ROWS 9
#define NUM_COLS 11

// Definišemo tabelu koju želimo da ispisujemo
static const char *table[] = {
    "|---------|",
    "| WHT BLK |",
    "|---------|",
    "| PUR WHT |",
    "|---------|",
    "| RED AQU |",
    "|---------|",
    "| WHT YEL |",
    "|---------|"
};

int *previous_state[NUM_ROWS][NUM_COLS];

int table_visible = 0;

// Podrazumevana opcija
int selected_option = 1;

void show_table();

// Pomeramo pokazivac u tabeli u odnosu na parametar. 1 = Nadole, 0 - Nagore
// Povecavamo odabranu opciju za 2 jer parni redovi sadrze separator opcija u tabeli (|---------|)
void table_select_option(int direction) {
    if (!table_visible) {
        return;
    }

    if (direction == 1) {
        selected_option = selected_option + 2;
    } else {
        selected_option = selected_option - 2;
    }

    if (selected_option < 1) {
        selected_option = 1;
    }

    if (selected_option > 7) {
        selected_option = 7;
    }

    show_table();
}

void toggle_table() {
    // Ukoliko je tabela bila otvorena zatvaramo je i vracamo prethodno stanje u graficku memoriju
    if (table_visible) {
        hide_table();

        table_visible = 0;
        return;
    }

    // Cuvamo prethodno stanje koje se nalazilo na konzoli
    for (int i = 0; i < NUM_ROWS; i++) {
        for (int j = 0; j < NUM_COLS; j++) {
            previous_state[i][j] = crt[j + 80*(i+1) - NUM_COLS];
        }
    }

    // Prikazujemo tabelu
    show_table();

    table_visible = 1;
}

// Racunamo boju reda u tabeli u odnosu na selektovanu opciju kako bi je graficki prikazali
int calculate_row_color(int row) {
    if (selected_option == row) {
        return 0x2000;
    }

    return 0x7000;
}

// Racunamo boju u odnosu na odabranu opciju u tabeli
int get_selected_console_color() {
    if (selected_option == 1) {
        return 0x0700;
    }

    if (selected_option == 3) {
        return 0x7500;
    }

    if (selected_option == 5) {
        return 0x3400;
    }

    if (selected_option == 7) {
        return 0x6700;
    }

    return 0x0700;
}

void show_table() {
    // Prolazimo kroz svaki red tabele i svaki karakter u redu
    for (int i = 0; i < NUM_ROWS; i++) {
        for (int j = 0; j < NUM_COLS; j++) {
            crt[j + 80*(i+1) - NUM_COLS] = table[i][j] | calculate_row_color(i);
        }
    }
}

void hide_table() {
    if (!is_table_visible()) {
        return;
    }

    // Vracamo u graficku memoriju prethodno stanje koje smo sacuvali.
    for (int i = 0; i < NUM_ROWS; i++) {
        for (int j = 0; j < NUM_COLS; j++) {
            crt[j + 80*(i+1) - NUM_COLS] = previous_state[i][j];
        }
    }
}

int is_table_visible() {
    return table_visible;
}
