#ifndef CONSOLE_H
    #define CONSOLE_H

    #include "types.h"
    #include "defs.h"
    #include "param.h"
    #include "traps.h"
    #include "spinlock.h"
    #include "sleeplock.h"
    #include "fs.h"
    #include "file.h"
    #include "memlayout.h"
    #include "mmu.h"
    #include "proc.h"
    #include "x86.h"
    #include "table.h"

    #define BACKSPACE 0x100
    #define CRTPORT 0x3d4
    static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory
#endif