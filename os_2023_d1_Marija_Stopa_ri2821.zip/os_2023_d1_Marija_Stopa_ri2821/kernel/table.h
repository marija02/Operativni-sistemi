#ifndef TABLE_H
    #define TABLE_H

    #include "console.h"

    extern void toggle_table();

    extern void table_select_option(int direction);
    extern int is_table_visible();
    extern int get_selected_console_color();
#endif